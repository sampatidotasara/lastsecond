# Eventr Project

Event management & RSVP system built with Django, Celery, Redis, and PostgreSQL.
