from django.db import models
from django.contrib.auth.models import User

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateTimeField()
    location = models.CharField(max_length=200)

    def __str__(self):
        return self.title

class Invitation(models.Model):
    STATUS_CHOICES = [('yes', 'Yes'), ('no', 'No'), ('maybe', 'Maybe')]
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='maybe')

    def __str__(self):
        return f"{self.user} - {self.event} ({self.status})"
