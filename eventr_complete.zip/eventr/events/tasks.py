from celery import shared_task
from django.core.mail import send_mail

@shared_task
def send_reminder_email():
    send_mail('Reminder','This is your reminder.','noreply@eventr.com',['test@example.com'])
