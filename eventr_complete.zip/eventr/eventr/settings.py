SECRET_KEY='dummy'
DEBUG=True
INSTALLED_APPS=['django.contrib.admin','django.contrib.auth','events']
